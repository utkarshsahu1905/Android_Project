package trainedge.scoop;

/**
 * Created by hp on 05-Apr-17.
 */

public class CategoryModel {
    String label;
    int image;

    public CategoryModel(String label, int image) {
        this.label = label;
        this.image = image;
    }
}
